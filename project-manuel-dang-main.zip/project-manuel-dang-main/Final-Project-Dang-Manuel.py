# Dang Nguyen
# ID: 1861688
# Professor : Dr Otto Dobretsberger
# CIS 3368 Final Project, Spring 2021

# Manuel Castillo
# ID: 1431705
# Professor : Dr Otto Dobretsberger
# CIS 3368 Final Project, Spring 2021

import random
import datetime
import time
import flask
from flask import jsonify
from flask import request, make_response
import mysql.connector
from mysql.connector import Error

#--------------------------------------------------------DATABASE------------------------------------------------------------------------------------------
# this first part is the connection to my database
# this function is to create the connection to mysql database
def create_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            passwd=user_password,
            database=db_name
        )
        print("Connection to MySQL DB successful") # this show the result of successful connect to my sql database
    except Error as e:
        print(f"The error '{e}' occurred")

    return connection

# this function is to send the query to mysql to execute
def execute_query(connection, query): 
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except Error as e:
        print(f"The error '{e}' occurred")
# this function is to read the query and to get back the result of query
def execute_read_query(connection, query):
    cursor = connection.cursor()
    result = None
    try:
        cursor.execute(query)
        result = cursor.fetchall()
        return result
    except Error as e:
        print(f"The error '{e}' occurred")

#--------------------------------------------------------APPLICATION-----------------------------------------------------------------------------------------

#setting up an application name
app = flask.Flask(__name__) #sets up the application
app.config["DEBUG"] = True #allow to show errors in browser

@app.route('/', methods=['GET']) # default url without any routing as GET request
def home():
    return "<h1>Hi !!! WELCOME TO OUR FIRST API! Created by Dang Nguyen(1861688) and Manuel Castillo(1431705)</h1>"

#-------------------------------------------------------FRIEND/USER-----------------------------------------------------------------------------------------

@app.route('/api/addfriend', methods=['POST']) #set up url POST REQUEST for adding friend to the database using postman
def adduser():
    request_data = request.get_json()
    firstname = request_data['firstname'] #firstname of user will be added
    lastname = request_data['lastname'] #lastname of user will be added
    conn = create_connection("cis3368.cbjbnstrbeir.us-east-2.rds.amazonaws.com", "dhnguy58", "Haidang.24121992", "cis3368db") # this is my information to the database
    query = "INSERT INTO friend (firstname, lastname ) VALUES ('{}','{}')".format(firstname,lastname) #writing query for database
    execute_query(conn, query)  #execute the query
    return 'POST REQUEST WORKED'   #check my table in mySQL Workbench to verify the user has been added

@app.route('/api/all/friend', methods = ['GET']) #set up url GET REQUEST for getting all the information of friend table and show in the browser
def api_friend():
    
    conn = create_connection("cis3368.cbjbnstrbeir.us-east-2.rds.amazonaws.com", "dhnguy58", "Haidang.24121992", "cis3368db") # this is my information to the database
    cursor = conn.cursor(dictionary=True)
    sql = "SELECT * FROM friend" #writing query for database

    cursor.execute(sql)
    rows = cursor.fetchall() 
    results = []
    
    x = results

    # Getting information from database and append it into results
    for user in rows:

            results.append(user)

    return jsonify((x)) # Show requested information as json format

@app.route('/api/friend', methods=['GET']) # set up urd GET REQUEST for getting user information by ID, ID is needed to be inserted in order to show the requested user.
def api_users_id():
    if 'id' in request.args: #only if an id is provided as an argument, proceed
        id = int(request.args['id'])
    else:
        return 'ERROR: No ID provided!' # If ID not found, it will show no id provided.

    conn = create_connection("cis3368.cbjbnstrbeir.us-east-2.rds.amazonaws.com", "dhnguy58", "Haidang.24121992", "cis3368db") # this is my information to the database
    cursor = conn.cursor(dictionary=True)
    sql = "SELECT * FROM friend" #writing query for database

    cursor.execute(sql)
    rows = cursor.fetchall()
    results = []

    for user in rows:
        if user['id'] == id: # inserted ID must be matched with ID in database
            results.append(user)
    return jsonify(results)     # Show requested information as json format

#--------------------------------------------------------MOVIE------------------------------------------------------------------------------------------

@app.route('/api/addmovie', methods=['POST']) #set up url POST REQUEST for adding movie that user wanted to the database using postman
def addmovie():
    request_data = request.get_json()
    
    movie1 = request_data['movie1']
    movie2 = request_data['movie2']
    movie3 = request_data['movie3']
    movie4 = request_data['movie4']
    movie5 = request_data['movie5']
    movie6 = request_data['movie6']
    movie7 = request_data['movie7']
    movie8 = request_data['movie8']
    movie9 = request_data['movie9']
    movie10 = request_data['movie10']
  
    conn = create_connection("cis3368.cbjbnstrbeir.us-east-2.rds.amazonaws.com", "dhnguy58", "Haidang.24121992", "cis3368db") # this is my information to the database
    
    #writing query for database
    query = "INSERT INTO movielist ( movie1, movie2, movie3, movie4, movie5, movie6, movie7, movie8, movie9, movie10 ) VALUES ('{}','{}','{}','{}''{}','{}''{}','{}''{}','{}')".format(movie1,movie2,movie3,movie4,movie5,movie6,movie7,movie8,movie9,movie10)
    
    execute_query(conn, query)  #check my table in mySQL Workbench to verify the movie has been added
    return 'POST REQUEST WORKED'  


@app.route('/api/all/movies', methods = ['GET']) #set up url GET REQUEST for getting all the information of movielist table and show in the browser
def api_all_movie():
   
    conn = create_connection("cis3368.cbjbnstrbeir.us-east-2.rds.amazonaws.com", "dhnguy58", "Haidang.24121992", "cis3368db") # this is my information to the database
    cursor = conn.cursor(dictionary=True)
    sql = "SELECT * FROM movielist" #writing query for database

    cursor.execute(sql)
    rows = cursor.fetchall()
    results = []
    
    x = results
    

    
    for user in rows:
            results.append(user)

    return jsonify(x) 

@app.route('/api/movie', methods=['GET']) #API to get a user with their movielist from the db table in AWS by id as a JSON response
def api_movie_id():
    if 'id' in request.args: #only if an id is provided as an argument, proceed
        id = int(request.args['id'])
    else:
        return 'ERROR: No ID provided!'

    conn = create_connection("cis3368.cbjbnstrbeir.us-east-2.rds.amazonaws.com", "dhnguy58", "Haidang.24121992", "cis3368db")  # this is my information to the database
    cursor = conn.cursor(dictionary=True)
    sql = "SELECT * FROM movielist"  #writing query for database

    cursor.execute(sql)
    rows = cursor.fetchall()
    results = []

    for user in rows:
        if user['id'] == id:
            results.append(user)
    return jsonify(results)

@app.route('/api/random/user/movies', methods = ['GET']) # Get random list of movie from movietable
def api_movie():

    conn = create_connection("cis3368.cbjbnstrbeir.us-east-2.rds.amazonaws.com", "dhnguy58", "Haidang.24121992", "cis3368db")  # this is my information to the database
    cursor = conn.cursor(dictionary=True)
    sql = "SELECT movie1, movie2, movie3, movie4, movie5, movie6, movie7, movie8, movie9, movie10 FROM movielist"  #writing query for database

    cursor.execute(sql)
    rows = cursor.fetchall()
    results = []
    
    
      
    for user in rows:
        results = len(user)
        num = random.randint(0,results)
        
    return jsonify(user['movie'+str(num)])

  
#------------------------------------------------------app.run()----------------------------------------------------------------------------------------

app.run()