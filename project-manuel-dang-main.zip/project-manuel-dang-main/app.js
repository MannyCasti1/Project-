// load the things we need
var express = require('express');
var app = express();
const bodyParser  = require('body-parser');
// required module to make calls to a REST API
const axios = require('axios');

app.use(bodyParser.urlencoded());

// set the view engine to ejs
app.set('view engine', 'ejs');

// index page, This is the app for index page
app.get('/', function(req, res) {

    axios.all([axios.get(`http://127.0.0.1:5000/api/all/friend`),
    axios.get(`http://127.0.0.1:5000/api/all/movies`)])     //For each page, i use axios.all to get multiple axios from API. This method i get multiple route because in case if i need to use API from all of them and i do not need to separate axios. Just get all them ome time and set different response 
    .then(axios.spread((firstResponse, secondResponse) => {     //This page i want to display the name of User
  
    var langs = firstResponse.data;                                         // This is APT from the first route(friend table) and i assigned it in langs
    var tagline = "Here is the data coming from my own API";                                
    var movies = secondResponse.data;                                        // This is APT from the seconds route(movie table) and i assigned it in movies       

    //use res.render to load up an ejs view file
    res.render('pages/index', {                                                 //This will render the index page with information of friend table and movie table
        langs: langs,
        tagline: tagline,
        movies: movies
    });
    }))
    .catch(error => console.log(error));
    
});

app.get('/movielist', function(req, res) {                                                 //This is movielist page, and i also use app.get to get API of movie list from back-end

    axios.all([axios.get(`http://127.0.0.1:5000/api/all/friend`),                       //route of all friend table
    axios.get(`http://127.0.0.1:5000/api/all/movies`)])                                 //route of movie list table
    .then(axios.spread((firstResponse, secondResponse) => {                                                                 //This page i want to display the name of movie in each movie list of users
  
    var langs = firstResponse.data;                                                         // This is APT from the first route(friend table) and i assigned it in langs
    var tagline = "Here is the data coming from my own API";
    var movies = secondResponse.data;                                                        // This is APT from the seconds route(movie table) and i assigned it in movies           

    //use res.render to load up an ejs view file
    res.render('pages/movielist', {                                                         ///This will render, display the content of movielist page and information of movie name
        langs: langs,
        tagline: tagline,
        movies: movies
    });
    }))
    .catch(error => console.log(error));
    
});

app.post('/add_friend', async function(req,res) {
    var first_name = req.body.firstname;
    var last_name = req.body.lastname;
 
  
 
    console.log(first_name);
    console.log(last_name);
 
  
 
    await axios.post('http://127.0.0.1:5000/api/addfriend' , { //
    //set variable to hold data
       firstname: first_name,
       lastname: last_name,
    })
    .then(function (response){
       console.log(response.data);
    })    
    res.render('index', {body: req.body})
});


 

app.get('/randomselection', function(req, res) {                                                                                            //This is random selection page

    axios.all([axios.get(`http://127.0.0.1:5000/api/all/friend`),
    axios.get(`http://127.0.0.1:5000/api/all/movies`),axios.get(`http://127.0.0.1:5000/api/random/user/movies`)])           //In this page i use axios.get to get all the API route that i need to display the information to the page
    .then(axios.spread((firstResponse, secondResponse, thirdResponse) => {  
  
    var langs = firstResponse.data;
    var tagline = "Here is the Movie List from each friends:";
    var movies = secondResponse.data;                                                                                       //This Page will show all the list of movie from each user
    var randoms = thirdResponse.data;                                                                                       //There al;so will be checkbox that allow user to pick the list of movie for randomize into one movie

    //use res.render to load up an ejs view file
    res.render('pages/randomselection', {                                           //This is to render the randomselection page
        langs: langs,
        tagline: tagline,
        movies: movies,                                                                             
        randoms: randoms
    });
    }))
    .catch(error => console.log(error));
    
});

app.post('/processdynamicform', function(req, res){                                                     //This is the app.post that allow user to submit a form.
    axios.get(`http://127.0.0.1:5000/api/random/user/movies`)                                           //After click the submit button. the form will be process and get the random movie from the random movie route
    .then((response)=>{
        
        var ranmovies = response.data;                                                                      //The randome movie route will be retrieved and be assignd into var ranmovies
        var tagline = "Here is the movie for Tonight:";
        console.log(ranmovies);                                                                 //This console log to display the retrieved API in the terminal
         // use res.render to load up an ejs view file  
        res.render('pages/thanks', {                                                              //once submit the form, it will lead user to the thanks page where will be display the name of once movie and the Thank you text for submitting the form.
            ranmovies: ranmovies,
            tagline: tagline
        });
    });
  
  })

const port = 3000                                                                       // I setup the port is 3000
app.listen(port, () => {
    console.log(`Front-end app listening at http://localhost:${port}`)
})
































